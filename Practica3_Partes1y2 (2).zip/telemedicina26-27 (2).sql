-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-09-2026 a las 19:53:44
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `telemedicina26-27`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `area_salud`
--

CREATE TABLE `area_salud` (
  `codigo_postal` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `gestor` int(11) NOT NULL,
  `sanitario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'sillas de ruedas'),
(2, 'termómetros'),
(3, 'estetoscopios'),
(4, 'tensiómetros'),
(5, 'material de curación'),
(6, 'material de laboratorio'),
(7, 'material de quirófano'),
(8, 'medicamentos'),
(9, 'electromedicina');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gestores`
--

CREATE TABLE `gestores` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `gestores`
--

INSERT INTO `gestores` (`id`, `nombre`, `apellidos`, `usuario`, `password`) VALUES
(1, 'Laura', 'Ruiz Torres', 'lauraruiztorres', 'lrt1234'),
(2, 'Miguel', 'Navarro Castro', 'miguelnavarrocastro', 'mnc5678'),
(3, 'Sofía', 'Moreno Silva', 'sofiamorenosilva', 'sms9012'),
(4, 'David', 'Vázquez Ramos', 'davidvazquezramos', 'dvr3456'),
(5, 'Lucía', 'Jiménez Flores', 'luciajimenezflores', 'ljf7890'),
(6, 'Javier', 'Romero Ortiz', 'javierromeroortiz', 'jro2345'),
(7, 'Marta', 'Serrano Vega', 'martaserranovega', 'msv1234'),
(8, 'Pablo', 'Cano Iglesias', 'pablocanoiglesias', 'pci7788'),
(9, 'Nuria', 'Gil Romero', 'nuriagilromero', 'ngr9900');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelos`
--

CREATE TABLE `modelos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `categoria` int(11) NOT NULL,
  `horas_maximas` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `modelos`
--

INSERT INTO `modelos` (`id`, `nombre`, `categoria`, `horas_maximas`) VALUES
(1, 'silla de ruedas eléctrica', 1, 72),
(2, 'silla de ruedas manual', 1, 72),
(3, 'termómetro digital', 2, 3),
(4, 'termómetro de mercurio', 2, 3),
(5, 'estetoscopio de doble campana', 3, 6),
(6, 'estetoscopio electrónico', 3, 6),
(7, 'tensiómetro de brazo', 4, 2),
(8, 'tensiómetro de muñeca', 4, 2),
(9, 'material de curación básico', 5, 8),
(10, 'material de curación avanzado', 5, 4),
(11, 'material de laboratorio general', 6, 12),
(12, 'material de laboratorio específico', 6, 12),
(13, 'material de quirófano general', 7, 6),
(14, 'material de quirófano específico', 7, 6),
(15, 'medicamento genérico', 8, 4),
(16, 'medicamento específico', 8, 4),
(17, 'bomba de infusión', 9, 24),
(18, 'monitor de constantes', 9, 24);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recurso`
--

CREATE TABLE `recurso` (
  `id` int(11) NOT NULL,
  `modelo` int(11) NOT NULL,
  `ubicacion` int(11) NOT NULL,
  `numero_serie` int(11) NOT NULL,
  `estado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `recurso`
--

INSERT INTO `recurso` (`id`, `modelo`, `ubicacion`, `numero_serie`, `estado`) VALUES
(1, 1, 6, 100001, 2),
(2, 2, 2, 100002, 0),
(3, 3, 9, 200001, 0),
(4, 4, 6, 200002, 0),
(5, 5, 9, 300001, 1),
(6, 6, 9, 300002, 0),
(7, 7, 9, 400001, 0),
(8, 8, 6, 400002, 0),
(9, 9, 9, 500001, 0),
(10, 10, 7, 500002, 0),
(11, 11, 3, 600001, 2),
(12, 12, 1, 600002, 0),
(13, 13, 5, 700001, 0),
(14, 14, 7, 700002, 2),
(15, 15, 10, 800001, 0),
(16, 16, 10, 800002, 0),
(17, 1, 4, 100011, 1),
(18, 2, 11, 100012, 0),
(19, 7, 12, 400010, 0),
(20, 17, 11, 900001, 0),
(21, 18, 11, 900002, 1),
(22, 1, 7, 12, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resenyas`
--

CREATE TABLE `resenyas` (
  `id` int(11) NOT NULL,
  `recurso` int(11) NOT NULL,
  `sanitario` int(11) NOT NULL,
  `fecha` varchar(100) NOT NULL,
  `valor` int(11) NOT NULL,
  `descripcion` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `resenyas`
--

INSERT INTO `resenyas` (`id`, `recurso`, `sanitario`, `fecha`, `valor`, `descripcion`) VALUES
(1, 2, 1, '2025-06-02 10:00:00', 5, 'Silla cómoda y en perfecto estado. Muy útil para el traslado.'),
(2, 3, 2, '2025-06-02 12:00:00', 4, 'Termómetro preciso. La funda algo desgastada.'),
(3, 5, 4, '2025-06-04 15:00:00', 5, 'Estetoscopio con muy buena acústica.'),
(4, 7, 6, '2025-06-06 11:00:00', 4, 'Funcionó sin problemas durante la toma de constantes.'),
(5, 10, 2, '2025-06-09 13:00:00', 3, 'Kit completo aunque faltaba una gasa.'),
(6, 11, 3, '2025-06-10 19:00:00', 4, 'Material bien organizado y limpio.'),
(7, 13, 5, '2025-06-12 15:00:00', 5, 'Instrumental en condiciones óptimas.'),
(8, 18, 8, '2025-11-11 12:00:00', 4, 'Silla ligera y manejable.'),
(9, 20, 9, '2026-02-21 10:00:00', 5, 'Bomba de infusión precisa y estable.'),
(10, 21, 10, '2026-02-23 11:00:00', 5, 'Monitor muy claro y fácil de configurar.'),
(11, 8, 7, '2026-02-23 12:00:00', 4, 'Tensiómetro cómodo y rápido.'),
(12, 6, 5, '2025-06-05 19:00:00', 4, 'Buena acústica durante la exploración.'),
(13, 15, 8, '2026-02-22 15:00:00', 3, 'Medicamento correcto aunque tardó en llegar.'),
(14, 16, 10, '2026-02-22 16:00:00', 4, 'Medicamento específico eficaz.'),
(15, 19, 9, '2026-01-06 11:00:00', 5, 'Tensiómetro preciso y fiable.'),
(16, 19, 3, '2026-01-06 11:00:00', 2, 'Tensiómetro malo y no fiable.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `id` int(11) NOT NULL,
  `recurso` int(11) NOT NULL,
  `sanitario` int(11) NOT NULL,
  `horas_estimadas` int(11) NOT NULL,
  `fecha_peticion` varchar(100) DEFAULT NULL,
  `fecha_inicio` varchar(100) DEFAULT NULL,
  `fecha_fin` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id`, `recurso`, `sanitario`, `horas_estimadas`, `fecha_peticion`, `fecha_inicio`, `fecha_fin`) VALUES
(1, 2, 1, 24, '2025-06-01 08:00:00', '2025-06-02 08:00:00', '2025-06-03 08:10:00'),
(2, 3, 2, 3, '2026-02-22 08:00:00', '2026-02-22 11:00:00', NULL),
(3, 4, 3, 200, '2025-06-03 09:00:00', '2026-02-23 09:00:00', NULL),
(4, 5, 4, 6, '2025-06-04 08:00:00', '2025-06-04 14:00:00', '2025-06-04 20:30:00'),
(5, 6, 6, 4, '2025-06-05 10:00:00', '2025-06-05 14:00:00', '2025-06-05 18:00:00'),
(6, 7, 6, 2, '2025-06-06 08:00:00', '2025-06-06 10:00:00', '2025-06-06 12:00:00'),
(7, 8, 7, 8, '2026-02-23 08:00:00', '2026-02-23 10:00:00', NULL),
(8, 9, 1, 8, '2025-06-08 08:00:00', '2025-06-08 16:00:00', '2025-06-09 01:00:00'),
(9, 10, 2, 4, '2025-06-09 08:00:00', '2025-06-09 12:00:00', '2025-06-09 16:00:00'),
(10, 11, 3, 10, '2025-06-10 08:00:00', '2025-06-10 18:00:00', '2025-06-11 04:00:00'),
(11, 12, 4, 12, '2025-06-11 08:00:00', '2025-06-11 20:00:00', '2025-06-12 08:00:00'),
(12, 13, 5, 6, '2026-02-19 08:00:00', '2026-02-21 12:00:00', NULL),
(13, 3, 6, 4, '2026-02-22 09:00:00', NULL, NULL),
(14, 13, 7, 5, '2026-02-20 20:00:00', '2027-02-21 12:00:00', NULL),
(15, 18, 8, 12, '2025-11-10 08:00:00', '2025-11-11 09:00:00', '2025-11-11 19:15:00'),
(16, 19, 9, 2, '2026-01-05 10:00:00', '2026-01-06 08:00:00', '2026-01-06 10:05:00'),
(17, 21, 10, 24, '2026-02-23 07:00:00', '2026-02-23 09:00:00', NULL),
(18, 20, 9, 8, '2026-02-20 16:00:00', '2026-02-21 08:00:00', NULL),
(19, 15, 8, 4, '2026-02-23 09:00:00', '2026-03-27 23:00:00', NULL),
(20, 16, 10, 4, '2026-02-23 10:00:00', NULL, NULL),
(21, 2, 1, 24, '2026-03-24 08:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sanitarios`
--

CREATE TABLE `sanitarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `sanitarios`
--

INSERT INTO `sanitarios` (`id`, `nombre`, `apellidos`, `usuario`, `password`) VALUES
(1, 'Juan', 'García Pérez', 'juangarciaperez', 'jgp1234'),
(2, 'María', 'López Sánchez', 'marialopezsanchez', 'mls5678'),
(3, 'Carlos', 'Martínez Gómez', 'carlosmartinezgomez', 'cmg9012'),
(4, 'Ana', 'Fernández Rodríguez', 'anafernandezrodriguez', 'afr3456'),
(5, 'Luis', 'Gómez Díaz', 'luisgomezdiaz', 'lgd7890'),
(6, 'Sofía', 'Hernández López', 'sofiahernandezlopez', 'shl2345'),
(7, 'Hugo', 'Lerma Vivar', 'hugolermavivar', 'hlv1234'),
(8, 'Elena', 'Pascual Núñez', 'elenapascualnunez', 'epn8822'),
(9, 'Iván', 'Santos Blanco', 'ivansantosblanco', 'isb5511'),
(10, 'Raúl', 'Ortega Molina', 'raulortegamolina', 'rom2244'),
(11, 'Diego', 'Sánchez López', 'diegosanchezlopez', 'dsl1234');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicaciones`
--

CREATE TABLE `ubicaciones` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ubicaciones`
--

INSERT INTO `ubicaciones` (`id`, `nombre`) VALUES
(1, 'laboratorio de microbiología'),
(2, 'almacén de material sanitario'),
(3, 'laboratorio de análisis clínicos'),
(4, 'laboratorio de inmunología'),
(5, 'quirófano'),
(6, 'sala de urgencias'),
(7, 'sala de esterilización'),
(8, 'sala de radiología'),
(9, 'sala de enfermería'),
(10, 'almacén de medicamentos'),
(11, 'unidad de cuidados intensivos (UCI)'),
(12, 'consulta de atención primaria');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `area_salud`
--
ALTER TABLE `area_salud`
  ADD PRIMARY KEY (`codigo_postal`),
  ADD KEY `area_salud_ibfk_1` (`gestor`),
  ADD KEY `sanitario` (`sanitario`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `gestores`
--
ALTER TABLE `gestores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indices de la tabla `modelos`
--
ALTER TABLE `modelos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `modelo_categoria` (`categoria`);

--
-- Indices de la tabla `recurso`
--
ALTER TABLE `recurso`
  ADD PRIMARY KEY (`id`),
  ADD KEY `recurso_ubicacion` (`ubicacion`),
  ADD KEY `recurso_modelo` (`modelo`);

--
-- Indices de la tabla `resenyas`
--
ALTER TABLE `resenyas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `resenyas_recurso` (`recurso`),
  ADD KEY `resenyas_sanitario` (`sanitario`);

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reservas_recurso` (`recurso`),
  ADD KEY `reserva_sanitario` (`sanitario`);

--
-- Indices de la tabla `sanitarios`
--
ALTER TABLE `sanitarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`);

--
-- Indices de la tabla `ubicaciones`
--
ALTER TABLE `ubicaciones`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `gestores`
--
ALTER TABLE `gestores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `modelos`
--
ALTER TABLE `modelos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `recurso`
--
ALTER TABLE `recurso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `resenyas`
--
ALTER TABLE `resenyas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `sanitarios`
--
ALTER TABLE `sanitarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `ubicaciones`
--
ALTER TABLE `ubicaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `area_salud`
--
ALTER TABLE `area_salud`
  ADD CONSTRAINT `area_salud_ibfk_1` FOREIGN KEY (`gestor`) REFERENCES `gestores` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `area_salud_ibfk_2` FOREIGN KEY (`sanitario`) REFERENCES `sanitarios` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `modelos`
--
ALTER TABLE `modelos`
  ADD CONSTRAINT `modelo_categoria` FOREIGN KEY (`categoria`) REFERENCES `categorias` (`id`);

--
-- Filtros para la tabla `recurso`
--
ALTER TABLE `recurso`
  ADD CONSTRAINT `recurso_modelo` FOREIGN KEY (`modelo`) REFERENCES `modelos` (`id`),
  ADD CONSTRAINT `recurso_ubicacion` FOREIGN KEY (`ubicacion`) REFERENCES `ubicaciones` (`id`);

--
-- Filtros para la tabla `resenyas`
--
ALTER TABLE `resenyas`
  ADD CONSTRAINT `resenyas_recurso` FOREIGN KEY (`recurso`) REFERENCES `recurso` (`id`),
  ADD CONSTRAINT `resenyas_sanitario` FOREIGN KEY (`sanitario`) REFERENCES `sanitarios` (`id`);

--
-- Filtros para la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `reserva_sanitario` FOREIGN KEY (`sanitario`) REFERENCES `sanitarios` (`id`),
  ADD CONSTRAINT `reservas_recurso` FOREIGN KEY (`recurso`) REFERENCES `recurso` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
