var http = require("http");
var WebSocketServer = require("websocket").server;
var datosServidor = require("./datos.js");

var sanitarios = datosServidor.san;
var gestores = datosServidor.ges;
var categorias = datosServidor.cat;
var modelos = datosServidor.mod;
var recursos = datosServidor.rec;
var reservas = datosServidor.res;

var httpServer = http.createServer();

// Configurar servidor WebSocket con protocolo "avisos"
var wsServer = new WebSocketServer({
    httpServer: httpServer
});

var puerto = 4444;

httpServer.listen(puerto, function () {
    console.log("Servidor WebSocket iniciado en puerto:", puerto);
});

// Array que almacena todos los clientes conectados actualmente
var clientes = [];

// Manejar nuevas conexiones WebSocket
wsServer.on("request", function (request) {
    var connection = request.accept("avisos", request.origin);

    // Objeto para almacenar información del cliente conectado
    var cliente = {
        connection: connection,
        tipo: null,      // "gestor" o "sanitario"
        idUsuario: null,
        nombre: null
    };

    clientes.push(cliente);
    console.log("Cliente WS conectado. Total:", clientes.length);

    // Escuchar mensajes entrantes del cliente
    connection.on("message", function (message) {
        if (message.type !== "utf8") return;

        var msg = JSON.parse(message.utf8Data);
        console.log("Mensaje WS recibido:", msg);

        // Procesar operaciones según tipo de mensaje recibido
        switch (msg.operacion) {
            case "identificar":
                identificarCliente(cliente, msg);
                break;

            case "recursoCreado":
                avisoRecursoCreado(cliente, msg.idRecurso);
                break;

            case "reservaIniciada":
                avisoReserva(cliente, msg.idReserva, "iniciada");
                break;

            case "reservaFinalizada":
                avisoReserva(cliente, msg.idReserva, "finalizada");
                break;

            case "resenyaCreada":
                avisoResenya(cliente, msg.idRecurso, msg.valoracion);
                break;
        }
    });

    // Limpiar cliente de la lista cuando se desconecte
    connection.on("close", function () {
        console.log("Cliente WS desconectado");
        for (var i = 0; i < clientes.length; i++) {
            if (clientes[i] === cliente) {
                clientes.splice(i, 1);
                break;
            }
        }
    });
});

function identificarCliente(cliente, msg) {
    cliente.tipo = msg.tipo;
    cliente.idUsuario = Number(msg.idUsuario);
    cliente.nombre = msg.nombre;

    if (cliente.tipo === "gestor") {
        var gestor = gestores.find(function (g) {
            return Number(g.id) === Number(cliente.idUsuario);
        });

        if (gestor) {
            cliente.nombre = gestor.nombre + " " + gestor.apellidos;
        }
    }

    if (cliente.tipo === "sanitario") {
        var sanitario = sanitarios.find(function (s) {
            return Number(s.id) === Number(cliente.idUsuario);
        });

        if (sanitario) {
            cliente.nombre = sanitario.nombre + " " + sanitario.apellidos;
        }
    }

    console.log("Cliente identificado:", cliente.tipo, cliente.idUsuario, cliente.nombre);
}

function enviarAviso(clienteDestino, aviso) {
    clienteDestino.connection.sendUTF(JSON.stringify({
        operacion: "aviso",
        fecha: new Date().toLocaleString(),
        origen: aviso.origen,
        texto: aviso.texto,
        color: aviso.color
    }));
}

// Obtener información completa de un recurso (recurso, modelo y categoría)
function obtenerDatosRecurso(idRecurso) {
    var recurso = recursos.find(function (r) {
        return Number(r.id) === Number(idRecurso);
    });

    if (!recurso) return null;

    var modelo = modelos.find(function (m) {
        return Number(m.id) === Number(recurso.modelo);
    });

    var categoria = categorias.find(function (c) {
        return modelo && Number(c.id) === Number(modelo.categoria);
    });

    return {
        recurso: recurso,
        modelo: modelo,
        categoria: categoria
    };
}

function obtenerNombreSanitario(idSanitario) {
    var sanitario = sanitarios.find(function (s) {
        return Number(s.id) === Number(idSanitario);
    });

    if (!sanitario) return "Sanitario";

    return sanitario.nombre + " " + sanitario.apellidos;
}

function obtenerNombreGestor(idGestor) {
    var gestor = gestores.find(function (g) {
        return Number(g.id) === Number(idGestor);
    });

    if (!gestor) return "Gestor";

    return gestor.nombre + " " + gestor.apellidos;
}

// Enviar aviso a todos los sanitarios cuando se crea un nuevo recurso
function avisoRecursoCreado(cliente, idRecurso) {
    var datos = obtenerDatosRecurso(idRecurso);
    if (!datos) return;

    var origen = cliente.nombre || obtenerNombreGestor(cliente.idUsuario);

    var texto = "SE HA CREADO UN NUEVO RECURSO " +
        datos.categoria.nombre.toUpperCase() +
        " MODELO " + datos.modelo.nombre.toUpperCase() +
        " CON CÓDIGO " + datos.recurso.numero_serie + ".";

    // Notificar a todos los sanitarios de que se crea un nuevo recurso (color azul)
    for (var i = 0; i < clientes.length; i++) {
        if (clientes[i].tipo === "sanitario") {
            enviarAviso(clientes[i], {
                origen: origen,
                texto: texto,
                color: "azul"
            });
        }
    }
}

// Enviar aviso sobre cambio en reserva (inicio o finalización)
function avisoReserva(cliente, idReserva, accion) {
    var reserva = reservas.find(function (r) {
        return Number(r.id) === Number(idReserva);
    });

    if (!reserva) return;

    var datos = obtenerDatosRecurso(reserva.recurso);
    if (!datos) return;

    var origen = cliente.nombre || obtenerNombreSanitario(cliente.idUsuario);

    // Determinar si la reserva fue iniciada o finalizada
    var accionTexto;
    if (accion === "iniciada") {
        accionTexto = "INICIADO";
    } else {
        accionTexto = "FINALIZADO";
    }
    var texto = `SE HA ${accionTexto} LA RESERVA DEL ${datos.categoria.nombre.toUpperCase()} MODELO ${datos.modelo.nombre.toUpperCase()} CON CÓDIGO ${datos.recurso.numero_serie}.`;

    // Notificar solo a sanitarios que tienen una reserva activa del mismo recurso (color rojo)
    for (var i = 0; i < clientes.length; i++) {
        if (clientes[i].tipo === "sanitario" &&
            sanitarioTieneReservaActiva(clientes[i].idUsuario, datos.recurso.id)) {

            enviarAviso(clientes[i], {
                origen: origen,
                texto: texto,
                color: "rojo"
            });
        }
    }
}

// Verificar si un sanitario tiene una reserva activa (sin fecha de fin) para un recurso
function sanitarioTieneReservaActiva(idSanitario, idRecurso) {
    for (var i = 0; i < reservas.length; i++) {
        if (Number(reservas[i].sanitario) === Number(idSanitario) &&
            Number(reservas[i].recurso) === Number(idRecurso) &&
            reservas[i].fecha_fin == null) {
            return true;
        }
    }

    return false;
}

// Enviar aviso a gestores cuando se crea una nueva reseña
function avisoResenya(cliente, idRecurso, valoracion) {
    var datos = obtenerDatosRecurso(idRecurso);
    if (!datos) return;

    var origen = cliente.nombre || obtenerNombreSanitario(cliente.idUsuario);

    var texto = "SE HA CREADO UNA RESEÑA PARA EL " +
        datos.categoria.nombre.toUpperCase() +
        " MODELO " + datos.modelo.nombre.toUpperCase() +
        " CON CÓDIGO " + datos.recurso.numero_serie +
        " Y PUNTUACIÓN " + valoracion + ".";

    // Notificar a todos los gestores (color verde)
    for (var i = 0; i < clientes.length; i++) {
        if (clientes[i].tipo === "gestor") {
            enviarAviso(clientes[i], {
                origen: origen,
                texto: texto,
                color: "verde"
            });
        }
    }
}