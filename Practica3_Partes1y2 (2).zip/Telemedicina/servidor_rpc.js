var conexion = require("./conexion_mysql.js");
var rpc = require("./rpc.js"); // incorporamos la libreria
var conexionBD = conexion; // las funciones usan conexionBD, así que la igualamos a conexion
rpc.debug = true;


/* ---------- CATÁLOGOS ---------- */

function obtenerCategorias(callback) {
    conexionBD.query("SELECT * FROM categorias", function (error, filas) {
        if (error) {
            console.log("Fallo al consultar las categorias");
            callback(null);
        } else {
            console.log("Categorias obtenidas: ", filas);
            callback(filas);
        }
    });
}

function obtenerUbicaciones(callback) {
    conexionBD.query("SELECT * FROM ubicaciones", function (error, filas) {
        if (error) {
            console.log("Fallo al consultar las ubicaciones");
            callback(null);
        } else {
            console.log("Ubicaciones obtenidas: ", filas);
            callback(filas);
        }
    });
}

function obtenerModelos(callback) {
    conexionBD.query("SELECT * FROM modelos", function (error, filas) {
        if (error) {
            console.log("Fallo al consultar los modelos");
            callback(null);
        } else {
            console.log("Modelos obtenidos: ", filas);
            callback(filas);
        }
    });
}


/* ---------- SANITARIOS ---------- */

function loginSanitario(usuario, password, callback) {
    var parametros = [usuario, password]; // mismo orden que los ? de la consulta
    conexionBD.query("SELECT id FROM sanitarios WHERE usuario = ? AND password =?", parametros, function (error, filas) {
        if (error) {
            console.log("Fallo en el login del sanitario");
            callback(null);
        } else if (filas.length == 0) {
            console.log("Login fallido: sanitario inexistente");
            callback(null);
        } else {
            console.log("Login correcto, id del sanitario: " + filas[0].id);
            callback(filas[0].id);
        }
    });
}

function crearSanitario(datosSanitario, callback) {
    if (!datosSanitario.nombre || !datosSanitario.apellidos || !datosSanitario.usuario || !datosSanitario.password) {
        return callback(null);
    }
    var consulta = "INSERT INTO sanitarios (nombre, apellidos, usuario, password) VALUES (?, ?, ?, ?)";
    var parametros = [datosSanitario.nombre, datosSanitario.apellidos, datosSanitario.usuario, datosSanitario.password];
    conexionBD.query(consulta, parametros, function (error, resultado) {
        if (error) {
            console.log("Fallo al insertar el sanitario:", error);
            callback(null);
        } else {
            callback(resultado.insertId); // id del registro insertado
        }
    });
}

function actualizarSanitario(idSanitario, datosSanitario, callback) {
    if (!datosSanitario.nombre || !datosSanitario.apellidos || !datosSanitario.usuario) {
        return callback(null);
    }
    var consulta;
    var parametros;
    // si viene contraseña se cambia, si no, se mantiene la anterior
    if (datosSanitario.password && datosSanitario.password.trim() !== "") {
        consulta = "UPDATE sanitarios SET nombre = ?, apellidos = ?, usuario = ?, password = ? WHERE id = ?";
        parametros = [datosSanitario.nombre, datosSanitario.apellidos, datosSanitario.usuario, datosSanitario.password, idSanitario];
    } else {
        consulta = "UPDATE sanitarios SET nombre = ?, apellidos = ?, usuario = ? WHERE id = ?";
        parametros = [datosSanitario.nombre, datosSanitario.apellidos, datosSanitario.usuario, idSanitario];
    }
    conexionBD.query(consulta, parametros, function (error, resultado) {
        if (error) {
            console.log("Fallo al modificar el sanitario:", error);
            callback(false);
        } else if (resultado.affectedRows === 1) {
            console.log("Sanitario modificado con éxito");
            callback(true);
        } else {
            console.log("Ningún sanitario ha sido modificado");
            callback(null);
        }
    });
}

function obtenerSanitario(idSanitario, callback) {
    conexionBD.query("SELECT nombre, apellidos, usuario FROM sanitarios WHERE id = " + idSanitario, function (error, filas) {
        if (error) {
            console.log("Fallo al consultar el sanitario");
            callback(null);
        } else if (filas.length === 0) {
            callback(null);
        } else {
            console.log("Sanitario obtenido: ", filas[0]);
            callback(filas[0]);
        }
    });
}


/* ---------- RECURSOS ---------- */

function obtenerRecurso(idRecurso, callback) {
    conexionBD.query("SELECT modelo, ubicacion, numero_serie, estado FROM recurso WHERE id = " + idRecurso, function (error, filas) {
        if (error) {
            console.log("Fallo al consultar el recurso");
            callback(null);
        } else if (filas.length === 0) {
            console.log("No existe ningun recurso con ese id");
            callback(null);
        } else {
            console.log("Recurso obtenido: ", filas[0]);
            callback(filas[0]);
        }
    });
}

function obtenerRecursos(idModelo, callback) {
    var parametros = [idModelo];
    conexionBD.query("SELECT * FROM recurso WHERE modelo = ? AND estado = 0", parametros, function (error, filas) {
        if (error) {
            console.log("Fallo al consultar los recursos del modelo");
            callback(null);
        } else {
            console.log("Recursos obtenidos: ", filas);
            callback(filas);
        }
    });
}


/* ---------- TIEMPOS DE ESPERA ---------- */

function tiempoPendiente(idRecurso, callback) {
    var tiempo = 0;
    var ahora = new Date();
    console.log("Hora actual:", ahora);
    conexionBD.query("SELECT * FROM reservas WHERE recurso = ? AND fecha_inicio IS NOT NULL AND fecha_fin IS NULL", [idRecurso], function (error, reservaEnUso) {
        if (error) {
            console.log("Fallo al consultar la reserva en uso:", error);
            return callback(null);
        }
        if (reservaEnUso.length > 0) {
            var inicio = new Date(reservaEnUso[0].fecha_inicio);
            console.log("Inicio de la reserva en uso:", inicio);
            var finEstimado = new Date(inicio.getTime() + reservaEnUso[0].horas_estimadas * 60 * 60 * 1000);
            var restante = (finEstimado.getTime() - ahora.getTime()) / (1000 * 60 * 60);
            if (restante > 0) {
                tiempo += restante;
            }
        }
        conexionBD.query("SELECT * FROM reservas WHERE recurso = ? AND fecha_inicio IS NULL AND fecha_fin IS NULL", [idRecurso], function (error, enEspera) {
            if (error) {
                console.log("Fallo al consultar las reservas en espera:", error);
                return callback(null);
            }
            for (var i = 0; i < enEspera.length; i++) {
                tiempo += Number(enEspera[i].horas_estimadas);
            }
            console.log("Tiempo pendiente total:", tiempo);
            callback(tiempo);
        });
    });
}


function tiempoPendienteReserva(idReserva, callback) {
    // 1. Localizamos la reserva de partida
    conexionBD.query("SELECT * FROM reservas WHERE id = ?", [idReserva], function (error, reservaBase) {
        if (error) {
            console.log("Fallo al localizar la reserva", error);
            return callback(null);
        }
        if (reservaBase.length === 0) {
            return callback(null);
        }
        var tiempo = 0;
        var idRecurso = reservaBase[0].recurso;

        // 2. Reservas del recurso que ya están en uso
        conexionBD.query("SELECT * FROM reservas WHERE recurso = ? AND fecha_inicio IS NOT NULL AND fecha_fin IS NULL", [idRecurso], function (error, enUso) {
            if (error) {
                console.log("Fallo al consultar las reservas en uso del recurso", error);
                return callback(null);
            }
            for (var i = 0; i < enUso.length; i++) {
                var reservaActiva = enUso[i];
                var inicio = new Date(reservaActiva.fecha_inicio);
                var ahora = new Date();
                var horasUsadas = (ahora - inicio) / (1000 * 60 * 60);
                var horasRestantes = Number(reservaActiva.horas_estimadas) - horasUsadas;
                if (horasRestantes > 0) {
                    tiempo += horasRestantes;
                }
            }

            // 3. Reservas en espera solicitadas antes que la nuestra
            conexionBD.query("SELECT * FROM reservas WHERE recurso = ? AND fecha_inicio IS NULL AND fecha_fin IS NULL AND fecha_peticion < ?", [idRecurso, reservaBase[0].fecha_peticion], function (error, anteriores) {
                if (error) {
                    console.log("Fallo al consultar las reservas en espera", error);
                    return callback(null);
                }
                for (var j = 0; j < anteriores.length; j++) {
                    tiempo += Number(anteriores[j].horas_estimadas);
                }
                console.log("Tiempo de espera de la reserva:", tiempo);
                callback(tiempo);
            });
        });
    });
}


/* ---------- RESERVAS ---------- */

function obtenerReservas(idSanitario, callback) {
    conexionBD.query("SELECT * FROM reservas WHERE sanitario = " + idSanitario, function (error, listaReservas) {
        if (error) {
            console.log("Fallo al consultar las reservas del sanitario");
            callback(null);
        } else {
            console.log("Reservas del sanitario: ", listaReservas);
            callback(listaReservas);
        }
    });
}

function reservarRecurso(idRecurso, idSanitario, horasEstimadas, callback) {
    if (horasEstimadas < 0) {
        console.log("Las horas estimadas no pueden ser negativas");
        return callback(null);
    }
    var consulta = "INSERT INTO reservas (recurso, sanitario, horas_estimadas, fecha_peticion) VALUES (?, ?, ?, ?)";
    var fecha = new Date().toISOString().split('.')[0] + "Z";
    var parametros = [idRecurso, idSanitario, horasEstimadas, fecha];
    conexionBD.query(consulta, parametros, function (error, resultado) {
        if (error) {
            console.log("Fallo al insertar la reserva:", error);
            callback(null);
        } else {
            console.log("Reserva registrada con id:", resultado.insertId);
            callback(resultado.insertId);
        }
    });
}

function iniciarReserva(idReserva, callback) {
    var consulta = "UPDATE reservas SET fecha_inicio = ? WHERE id = ?";
    var fecha = new Date().toISOString().split('.')[0] + "Z";
    var parametros = [fecha, idReserva];
    conexionBD.query(consulta, parametros, function (err, resultado) {
        if (err) {
            console.log("Fallo al arrancar la reserva", err);
            callback("Error al iniciar la reserva");
        } else if (resultado.affectedRows !== 1) {
            console.log("Ninguna reserva ha sido arrancada");
            callback("Reserva no iniciada");
        } else {
            console.log("Reserva arrancada con éxito");
            callback("Reserva iniciada correctamente");
        }
    });
}

function finalizarReserva(idReserva, callback) {
    var consulta = "UPDATE reservas SET fecha_fin = ? WHERE id = ?";
    var fecha = new Date().toISOString().split('.')[0] + "Z";
    var parametros = [fecha, idReserva];
    conexionBD.query(consulta, parametros, function (err, resultado) {
        if (err) {
            console.log("Fallo al cerrar la reserva", err);
            callback("Error al finalizar la reserva");
        } else if (resultado.affectedRows !== 1) {
            console.log("Ninguna reserva ha sido cerrada");
            callback("Reserva no finalizada");
        } else {
            console.log("Reserva cerrada con éxito");
            callback("Reserva finalizada correctamente");
        }
    });
}

function cancelarReserva(idReserva, callback) {
    var consulta = "DELETE FROM reservas WHERE id = " + idReserva;
    conexionBD.query(consulta, function (err, resultado) {
        if (err) {
            console.log("Fallo al borrar la reserva", err);
            callback("Error al realizar el cancelado");
        } else if (resultado.affectedRows !== 1) {
            console.log("Ninguna reserva ha sido borrada");
            callback("reserva no cancelada");
        } else {
            console.log("Reserva borrada con éxito");
            callback("Reserva cancelada");
        }
    });
}


/* ---------- RESEÑAS ---------- */

function obtenerResenyas(idRecurso, callback) {
    conexionBD.query("SELECT * FROM resenyas WHERE recurso = " + idRecurso, function (error, listaResenyas) {
        if (error) {
            console.log("Fallo al consultar las resenyas del recurso");
            callback(null);
        } else {
            console.log("Resenyas del recurso: ", listaResenyas);
            callback(listaResenyas);
        }
    });
}

function crearResenya(idRecurso, idSanitario, valoracion, descripcion, callback) {
    var consulta = "INSERT INTO resenyas (recurso, sanitario, fecha, valor, descripcion) VALUES (?, ?, ?, ?, ?)";
    var fecha = new Date().toISOString().split('.')[0] + "Z";

    // valores en el mismo orden que los ? de la consulta
    var parametros = [idRecurso, idSanitario, fecha, valoracion, descripcion];

    conexionBD.query(consulta, parametros, function (error, resultado) {
        if (error) {
            console.log("Fallo al insertar la resenya:", error);
            callback(null);
        } else {
            console.log("Resenya registrada con id:", resultado.insertId);
            callback(resultado.insertId);
        }
    });
}



/* ---------- SERVIDOR RPC ---------- */

var servidor = rpc.server(); // crear el servidor RPC
var app = servidor.createApp("servidor_rpc"); // crear aplicación de RPC

// Registramos los procedimientos
app.registerAsync(obtenerCategorias);
app.registerAsync(obtenerUbicaciones);
app.registerAsync(obtenerModelos);
app.registerAsync(loginSanitario);
app.registerAsync(crearSanitario);
app.registerAsync(actualizarSanitario);
app.registerAsync(obtenerSanitario);
app.registerAsync(obtenerRecurso);
app.registerAsync(obtenerRecursos);
app.registerAsync(tiempoPendiente);
app.registerAsync(tiempoPendienteReserva);
app.registerAsync(obtenerReservas);
app.registerAsync(reservarRecurso);
app.registerAsync(iniciarReserva);
app.registerAsync(finalizarReserva);
app.registerAsync(cancelarReserva);
app.registerAsync(obtenerResenyas);
app.registerAsync(crearResenya);