var sanitarios = [
  {"id":1, "nombre":"Juan",   "apellidos":"García Pérez",        "usuario":"juangarciaperez",        "password":"jgp1234"},
  {"id":2, "nombre":"María",  "apellidos":"López Sánchez",       "usuario":"marialopezsanchez",      "password":"mls5678"},
  {"id":3, "nombre":"Carlos", "apellidos":"Martínez Gómez",      "usuario":"carlosmartinezgomez",    "password":"cmg9012"},
  {"id":4, "nombre":"Ana",    "apellidos":"Fernández Rodríguez", "usuario":"anafernandezrodriguez",  "password":"afr3456"},
  {"id":5, "nombre":"Luis",   "apellidos":"Gómez Díaz",          "usuario":"luisgomezdiaz",          "password":"lgd7890"},
  {"id":6, "nombre":"Sofía",  "apellidos":"Hernández López",     "usuario":"sofiahernandezlopez",    "password":"shl2345"},
  {"id":7, "nombre":"Hugo",   "apellidos":"Lerma Vivar",         "usuario":"hugolermavivar",         "password":"hlv1234"},
  {"id":8,  "nombre":"Elena", "apellidos":"Pascual Núñez",       "usuario":"elenapascualnunez",      "password":"epn8822"},
  {"id":9,  "nombre":"Iván",  "apellidos":"Santos Blanco",       "usuario":"ivansantosblanco",       "password":"isb5511"},
  {"id":10, "nombre":"Raúl",  "apellidos":"Ortega Molina",       "usuario":"raulortegamolina",       "password":"rom2244"}
];

var gestores = [
  {"id":1, "nombre":"Laura",  "apellidos":"Ruiz Torres",      "usuario":"lauraruiztorres",      "password":"lrt1234"},
  {"id":2, "nombre":"Miguel", "apellidos":"Navarro Castro",   "usuario":"miguelnavarrocastro",   "password":"mnc5678"},
  {"id":3, "nombre":"Sofía",  "apellidos":"Moreno Silva",     "usuario":"sofiamorenosilva",      "password":"sms9012"},
  {"id":4, "nombre":"David",  "apellidos":"Vázquez Ramos",    "usuario":"davidvazquezramos",     "password":"dvr3456"},
  {"id":5, "nombre":"Lucía",  "apellidos":"Jiménez Flores",   "usuario":"luciajimenezflores",    "password":"ljf7890"},
  {"id":6, "nombre":"Javier", "apellidos":"Romero Ortiz",     "usuario":"javierromeroortiz",     "password":"jro2345"},
  {"id":7, "nombre":"Marta",  "apellidos":"Serrano Vega",     "usuario":"martaserranovega",      "password":"msv1234"},
  {"id":8,  "nombre":"Pablo", "apellidos":"Cano Iglesias",    "usuario":"pablocanoiglesias",     "password":"pci7788"},
  {"id":9,  "nombre":"Nuria", "apellidos":"Gil Romero",       "usuario":"nuriagilromero",        "password":"ngr9900"} 
];
var ubicaciones = [
  {"id":1,  "nombre":"laboratorio de microbiología"},
  {"id":2,  "nombre":"almacén de material sanitario"},
  {"id":3,  "nombre":"laboratorio de análisis clínicos"},
  {"id":4,  "nombre":"laboratorio de inmunología"},
  {"id":5,  "nombre":"quirófano"},
  {"id":6,  "nombre":"sala de urgencias"},
  {"id":7,  "nombre":"sala de esterilización"},
  {"id":8,  "nombre":"sala de radiología"},
  {"id":9,  "nombre":"sala de enfermería"},
  {"id":10, "nombre":"almacén de medicamentos"},
  {"id":11, "nombre":"unidad de cuidados intensivos (UCI)"},
  {"id":12, "nombre":"consulta de atención primaria"}
];

var categorias = [
  {"id":1, "nombre":"sillas de ruedas"},
  {"id":2, "nombre":"termómetros"},
  {"id":3, "nombre":"estetoscopios"},
  {"id":4, "nombre":"tensiómetros"},
  {"id":5, "nombre":"material de curación"},
  {"id":6, "nombre":"material de laboratorio"},
  {"id":7, "nombre":"material de quirófano"},
  {"id":8, "nombre":"medicamentos"},
  {"id":9, "nombre":"electromedicina"}
];

var modelos = [
  {"id":1,  "nombre":"silla de ruedas eléctrica",          "categoria":1, "horas_maximas":72},
  {"id":2,  "nombre":"silla de ruedas manual",            "categoria":1, "horas_maximas":72},
  {"id":3,  "nombre":"termómetro digital",                "categoria":2, "horas_maximas":3},
  {"id":4,  "nombre":"termómetro de mercurio",            "categoria":2, "horas_maximas":3},
  {"id":5,  "nombre":"estetoscopio de doble campana",     "categoria":3, "horas_maximas":6},
  {"id":6,  "nombre":"estetoscopio electrónico",          "categoria":3, "horas_maximas":6},
  {"id":7,  "nombre":"tensiómetro de brazo",              "categoria":4, "horas_maximas":2},
  {"id":8,  "nombre":"tensiómetro de muñeca",             "categoria":4, "horas_maximas":2},
  {"id":9,  "nombre":"material de curación básico",       "categoria":5, "horas_maximas":8},
  {"id":10, "nombre":"material de curación avanzado",     "categoria":5, "horas_maximas":4},
  {"id":11, "nombre":"material de laboratorio general",   "categoria":6, "horas_maximas":12},
  {"id":12, "nombre":"material de laboratorio específico","categoria":6, "horas_maximas":12},
  {"id":13, "nombre":"material de quirófano general",     "categoria":7, "horas_maximas":6},
  {"id":14, "nombre":"material de quirófano específico",  "categoria":7, "horas_maximas":6},
  {"id":15, "nombre":"medicamento genérico",              "categoria":8, "horas_maximas":4},
  {"id":16, "nombre":"medicamento específico",            "categoria":8, "horas_maximas":4},  
  {"id":17, "nombre":"bomba de infusión",                  "categoria":9, "horas_maximas":24},
  {"id":18, "nombre":"monitor de constantes",              "categoria":9, "horas_maximas":24}
];

// estado: 0 operativo, 1 de baja/defectuoso, 2 en mantenimiento
var recurso = [
  {"id":1,  "modelo":1,  "ubicacion":6,  "numero_serie":100001, "estado":2}, 
  {"id":2,  "modelo":2,  "ubicacion":2,  "numero_serie":100002, "estado":0},
  {"id":3,  "modelo":3,  "ubicacion":9,  "numero_serie":200001, "estado":0},
  {"id":4,  "modelo":4,  "ubicacion":6,  "numero_serie":200002, "estado":0},
  {"id":5,  "modelo":5,  "ubicacion":9,  "numero_serie":300001, "estado":1},
  {"id":6,  "modelo":6,  "ubicacion":9,  "numero_serie":300002, "estado":0},
  {"id":7,  "modelo":7,  "ubicacion":9,  "numero_serie":400001, "estado":0},
  {"id":8,  "modelo":8,  "ubicacion":6,  "numero_serie":400002, "estado":0},
  {"id":9,  "modelo":9,  "ubicacion":9,  "numero_serie":500001, "estado":0},
  {"id":10, "modelo":10, "ubicacion":7,  "numero_serie":500002, "estado":0},
  {"id":11, "modelo":11, "ubicacion":3,  "numero_serie":600001, "estado":2},
  {"id":12, "modelo":12, "ubicacion":1,  "numero_serie":600002, "estado":0},
  {"id":13, "modelo":13, "ubicacion":5,  "numero_serie":700001, "estado":0},
  {"id":14, "modelo":14, "ubicacion":7,  "numero_serie":700002, "estado":2}, 
  {"id":15, "modelo":15, "ubicacion":10, "numero_serie":800001, "estado":0},
  {"id":16, "modelo":16, "ubicacion":10, "numero_serie":800002, "estado":0},
  {"id":17,  "modelo":1,  "ubicacion":4,  "numero_serie":100011, "estado":1},
  {"id":18, "modelo":2,  "ubicacion":11, "numero_serie":100012, "estado":0},
  {"id":19, "modelo":7,  "ubicacion":12, "numero_serie":400010, "estado":0},
  {"id":20, "modelo":17, "ubicacion":11, "numero_serie":900001, "estado":0},
  {"id":21, "modelo":18, "ubicacion":11, "numero_serie":900002, "estado":1}
];
// ej. recurso 1-> sin reservas, recurso 2-> reserva finalizada, recurso 3-> reserva pasada de horas y espera de reserva, recurso 4-> reserva en curso
var reservas = [
  {"id":1,  "recurso":2,  "sanitario":1,  "horas_estimadas":24, "fecha_peticion":"2025-06-01T08:00:00Z", "fecha_inicio":"2025-06-02T08:00:00Z", "fecha_fin":"2025-06-03T08:10:00Z"},
  {"id":2,  "recurso":3,  "sanitario":2,  "horas_estimadas":3,  "fecha_peticion":"2026-02-22T08:00:00Z", "fecha_inicio":"2026-02-22T11:00:00Z", "fecha_fin":null},
  {"id":3,  "recurso":4,  "sanitario":3,  "horas_estimadas":200,  "fecha_peticion":"2025-06-03T09:00:00Z", "fecha_inicio":"2026-02-23T09:00:00Z", "fecha_fin":null},
  {"id":4,  "recurso":5,  "sanitario":4,  "horas_estimadas":6,  "fecha_peticion":"2025-06-04T08:00:00Z", "fecha_inicio":"2025-06-04T14:00:00Z", "fecha_fin":"2025-06-04T20:30:00Z"},
  {"id":5,  "recurso":6,  "sanitario":6,  "horas_estimadas":4,  "fecha_peticion":"2025-06-05T10:00:00Z", "fecha_inicio":"2025-06-05T14:00:00Z", "fecha_fin":"2025-06-05T18:00:00Z"},
  {"id":6,  "recurso":7,  "sanitario":6,  "horas_estimadas":2,  "fecha_peticion":"2025-06-06T08:00:00Z", "fecha_inicio":"2025-06-06T10:00:00Z", "fecha_fin":"2025-06-06T12:00:00Z"},
  {"id":7,  "recurso":8,  "sanitario":7,  "horas_estimadas":8,  "fecha_peticion":"2026-02-23T08:00:00Z", "fecha_inicio":"2026-02-23T10:00:00Z", "fecha_fin":null},
  {"id":8,  "recurso":9,  "sanitario":1,  "horas_estimadas":8,  "fecha_peticion":"2025-06-08T08:00:00Z", "fecha_inicio":"2025-06-08T16:00:00Z", "fecha_fin":"2025-06-09T01:00:00Z"},
  {"id":9,  "recurso":10, "sanitario":2,  "horas_estimadas":4,  "fecha_peticion":"2025-06-09T08:00:00Z", "fecha_inicio":"2025-06-09T12:00:00Z", "fecha_fin":"2025-06-09T16:00:00Z"},
  {"id":10, "recurso":11, "sanitario":3,  "horas_estimadas":10, "fecha_peticion":"2025-06-10T08:00:00Z", "fecha_inicio":"2025-06-10T18:00:00Z", "fecha_fin":"2025-06-11T04:00:00Z"},
  {"id":11, "recurso":12, "sanitario":4,  "horas_estimadas":12, "fecha_peticion":"2025-06-11T08:00:00Z", "fecha_inicio":"2025-06-11T20:00:00Z", "fecha_fin":"2025-06-12T08:00:00Z"},
  {"id":12, "recurso":13, "sanitario":5,  "horas_estimadas":6,  "fecha_peticion":"2026-02-19T08:00:00Z", "fecha_inicio":"2026-02-21T12:00:00Z", "fecha_fin":null},
  {"id":13, "recurso":3,  "sanitario":6,  "horas_estimadas":4,  "fecha_peticion":"2026-02-22T09:00:00Z", "fecha_inicio":null, "fecha_fin":null},
  {"id":14, "recurso":13, "sanitario":7,  "horas_estimadas":5,  "fecha_peticion":"2026-02-20T20:00:00Z", "fecha_inicio":"2027-02-21T12:00:00Z", "fecha_fin":null},
  {"id":15, "recurso":18, "sanitario":8,  "horas_estimadas":12, "fecha_peticion":"2025-11-10T08:00:00Z", "fecha_inicio":"2025-11-11T09:00:00Z", "fecha_fin":"2025-11-11T19:15:00Z"},
  {"id":16, "recurso":19, "sanitario":9,  "horas_estimadas":2,  "fecha_peticion":"2026-01-05T10:00:00Z", "fecha_inicio":"2026-01-06T08:00:00Z", "fecha_fin":"2026-01-06T10:05:00Z"},
  {"id":17, "recurso":21, "sanitario":10, "horas_estimadas":24, "fecha_peticion":"2026-02-23T07:00:00Z", "fecha_inicio":"2026-02-23T09:00:00Z", "fecha_fin":null},
  {"id":18, "recurso":20, "sanitario":9,  "horas_estimadas":8,  "fecha_peticion":"2026-02-20T16:00:00Z", "fecha_inicio":"2026-02-21T08:00:00Z", "fecha_fin":null},
  {"id":19, "recurso":15, "sanitario":8,  "horas_estimadas":4,  "fecha_peticion":"2026-02-23T09:00:00Z", "fecha_inicio":"2026-03-27T23:00:00Z", "fecha_fin":null},
  {"id":20, "recurso":16, "sanitario":10, "horas_estimadas":4,  "fecha_peticion":"2026-02-23T10:00:00Z", "fecha_inicio":null, "fecha_fin":null},
  {"id":21,  "recurso":2,  "sanitario":1,  "horas_estimadas":24, "fecha_peticion":"2026-03-24T08:00:00Z", "fecha_inicio":null, "fecha_fin":null},
];

var resenyas = [
  {"id":1, "recurso":2,  "sanitario":1,  "fecha":"2025-06-02T10:00:00Z", "valor":5, "descripcion":"Silla cómoda y en perfecto estado. Muy útil para el traslado."},
  {"id":2, "recurso":3,  "sanitario":2,  "fecha":"2025-06-02T12:00:00Z", "valor":4, "descripcion":"Termómetro preciso. La funda algo desgastada."},
  {"id":3, "recurso":5,  "sanitario":4,  "fecha":"2025-06-04T15:00:00Z", "valor":5, "descripcion":"Estetoscopio con muy buena acústica."},
  {"id":4, "recurso":7,  "sanitario":6,  "fecha":"2025-06-06T11:00:00Z", "valor":4, "descripcion":"Funcionó sin problemas durante la toma de constantes."},
  {"id":5, "recurso":10, "sanitario":2,  "fecha":"2025-06-09T13:00:00Z", "valor":3, "descripcion":"Kit completo aunque faltaba una gasa."},
  {"id":6, "recurso":11, "sanitario":3,  "fecha":"2025-06-10T19:00:00Z", "valor":4, "descripcion":"Material bien organizado y limpio."},
  {"id":7, "recurso":13, "sanitario":5,  "fecha":"2025-06-12T15:00:00Z", "valor":5, "descripcion":"Instrumental en condiciones óptimas."},
  {"id":8, "recurso":18, "sanitario":8,  "fecha":"2025-11-11T12:00:00Z", "valor":4, "descripcion":"Silla ligera y manejable."},
  {"id":9, "recurso":20, "sanitario":9,  "fecha":"2026-02-21T10:00:00Z", "valor":5, "descripcion":"Bomba de infusión precisa y estable."},
  {"id":10,"recurso":21, "sanitario":10, "fecha":"2026-02-23T11:00:00Z", "valor":5, "descripcion":"Monitor muy claro y fácil de configurar."},
  {"id":11,"recurso":8,  "sanitario":7,  "fecha":"2026-02-23T12:00:00Z", "valor":4, "descripcion":"Tensiómetro cómodo y rápido."},
  {"id":12,"recurso":6,  "sanitario":5,  "fecha":"2025-06-05T19:00:00Z", "valor":4, "descripcion":"Buena acústica durante la exploración."},
  {"id":13,"recurso":15, "sanitario":8,  "fecha":"2026-02-22T15:00:00Z", "valor":3, "descripcion":"Medicamento correcto aunque tardó en llegar."},
  {"id":14,"recurso":16, "sanitario":10, "fecha":"2026-02-22T16:00:00Z", "valor":4, "descripcion":"Medicamento específico eficaz."},
  {"id":15,"recurso":19, "sanitario":9,  "fecha":"2026-01-06T11:00:00Z", "valor":5, "descripcion":"Tensiómetro preciso y fiable."},
  {"id":16,"recurso":19, "sanitario":3,  "fecha":"2026-01-06T11:00:00Z", "valor":2, "descripcion":"Tensiómetro malo y no fiable."}
];

module.exports.san=sanitarios
module.exports.ges=gestores
module.exports.ub=ubicaciones
module.exports.cat=categorias
module.exports.mod=modelos
module.exports.rec=recurso
module.exports.res=reservas
module.exports.resen=resenyas