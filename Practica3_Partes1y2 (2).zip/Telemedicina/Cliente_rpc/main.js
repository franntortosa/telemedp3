//Vinculamos cliente - servidor. Obtener una referencia a la app RPC (instancia de la aplicación gestion pacientes del servidor localhost)
var app = rpc("localhost", "servidor_rpc");

var obtenerCategorias = app.procedure("obtenerCategorias");
var obtenerModelos = app.procedure("obtenerModelos");
var obtenerUbicaciones = app.procedure("obtenerUbicaciones");
var loginSanitario = app.procedure("loginSanitario");
var crearSanitario = app.procedure("crearSanitario");
var actualizarSanitario = app.procedure("actualizarSanitario");
var obtenerSanitario = app.procedure("obtenerSanitario");
var obtenerRecursos = app.procedure("obtenerRecursos");
var tiempoPendiente = app.procedure("tiempoPendiente");
var obtenerReservas = app.procedure("obtenerReservas");
var obtenerResenyas = app.procedure("obtenerResenyas");
var crearResenya = app.procedure("crearResenya");
var reservarRecurso = app.procedure("reservarRecurso");
var cancelarReserva = app.procedure("cancelarReserva");
var iniciarReserva = app.procedure("iniciarReserva");
var finalizarReserva = app.procedure("finalizarReserva");
var obtenerRecurso = app.procedure("obtenerRecurso");
var tiempoPendienteReserva = app.procedure("tiempoPendienteReserva");

var esNuevoRegistro=true;
var seccionActual = "inicio";
var sanitarioLogueado=null;
var guardar_resenya= false;
var recursoResenya_id=null;
var conexionWS = null;
var avisos = [];
var cargaReservasActual = 0;

//WEB SOCKETS
function abrirWSSanitario() {
    conexionWS = new WebSocket("ws://localhost:4444", "avisos");

    // Evento al establecer la conexión: enviar datos de identificación del sanitario
    conexionWS.addEventListener("open", function () {
        conexionWS.send(JSON.stringify({
            operacion: "identificar",
            tipo: "sanitario",
            idUsuario: idSanitarioLogueado,
            nombre: sanitarioLogueado.nombre + " " + sanitarioLogueado.apellidos
        }));
    });

    // Evento al recibir un mensaje: procesar aviso y actualizar tablas si es necesario
    conexionWS.addEventListener("message", function (msg) {
        var aviso = JSON.parse(msg.data);

        // Si es un aviso válido, añadirlo al array y mostrar en tabla
        if (aviso.operacion === "aviso") {
            avisos.push(aviso);
            pintarAvisos();
        }

        // Si el aviso es rojo (cambio en reservas), recargar tabla de reservas
        if (aviso.color === "rojo") {
            cargarTablasReservas(idSanitarioLogueado);
        }
    });
}

// Cerrar conexión WebSocket y limpiar referencia
function cerrarWS() {
    if (conexionWS != null) {
        conexionWS.close();
        conexionWS = null;
    }
}

function enviarWS(objeto) {
    if (conexionWS != null && conexionWS.readyState === WebSocket.OPEN) {
        conexionWS.send(JSON.stringify(objeto));
    }
}

// Renderizar la tabla de avisos en la pantalla
// Asigna colores según el tipo de aviso (rojo, azul, verde)
function pintarAvisos() {
    var tbody = document.getElementById("tabla_avisos_body");
    tbody.innerHTML = "";

    // Recorrer array de avisos y crear una fila para cada uno
    for (var i = 0; i < avisos.length; i++) {
        var tr = document.createElement("tr");

        // Asignar color de fondo según el tipo de aviso
        if (avisos[i].color === "rojo") tr.style.backgroundColor = "#ffcccc";    // Cambios en reservas
        if (avisos[i].color === "azul") tr.style.backgroundColor = "#cce5ff";    // Nuevos recursos
        if (avisos[i].color === "verde") tr.style.backgroundColor = "#ccffcc";   // Nuevas reseñas

        // Insertar datos del aviso: fecha, origen (quién lo generó), texto del aviso
        tr.innerHTML =
            "<td>" + avisos[i].fecha + "</td>" +
            "<td>" + avisos[i].origen + "</td>" +
            "<td>" + avisos[i].texto + "</td>";

        tbody.appendChild(tr);
    }
}
//FIN WEB SOCKETS

function cambiarSeccion(seccion) {  //permite cambiar entre las diferentes secciones
    document.getElementById(seccionActual).classList.remove("activa");
    document.getElementById(seccion).classList.add("activa");
    seccionActual = seccion;
}

function formatearFecha(fechaISO) {
    if (fechaISO == null) { 
        return "";
    }
    var fecha = new Date(fechaISO);
    return fecha.toLocaleString(); // Formatea la fecha en formato local
}

function retirarReserva(idReserva) {
    iniciarReserva(idReserva, function (respuesta) {

        enviarWS({
            operacion: "reservaIniciada",
            idReserva: idReserva
        });

        cargarTablasReservas(idSanitarioLogueado);
    });
}

function borrarReserva(idReserva) {
    cancelarReserva(idReserva, function (respuesta) {
        cargarTablasReservas(idSanitarioLogueado);
    });
}

function devolverReserva(idReserva) {
    finalizarReserva(idReserva, function (respuesta) {

        enviarWS({
            operacion: "reservaFinalizada",
            idReserva: idReserva
        });

        cargarTablasReservas(idSanitarioLogueado);
    });
}

function llenarSelect(selectId, opciones){
    var select = document.getElementById(selectId);
    select.innerHTML = ""; // Limpiar opciones anteriores
    for (var i = 0; i < opciones.length; i++) {
        var option = document.createElement("option"); //crea elemento option, se le asigna el id y pone el nombre del objeto
        option.value = opciones[i].id; 
        option.textContent = opciones[i].nombre;
        select.appendChild(option);
    }
}
function cargarTablasReservas(idSanitario) {
    cargaReservasActual++;
    var numeroCarga = cargaReservasActual;

    var tbodyPendientes = document.getElementById("reservas_pendientes_body");
    var tbodyRealizadas = document.getElementById("reservas_realizadas_body");

    tbodyPendientes.innerHTML = "";
    tbodyRealizadas.innerHTML = "";

    var hayPendientes = false;
    var hayRealizadas = false;

    obtenerReservas(idSanitario, function (reservas) {
        if (numeroCarga !== cargaReservasActual) {
            return;
        }

        if (!reservas || reservas.length === 0) {
            var tr1 = document.createElement("tr");
            tr1.innerHTML = "<td colspan='8'>No hay reservas pendientes</td>";
            tbodyPendientes.appendChild(tr1);

            var tr2 = document.createElement("tr");
            tr2.innerHTML = "<td colspan='7'>No hay reservas realizadas</td>";
            tbodyRealizadas.appendChild(tr2);
            return;
        }

        for (var i = 0; i < reservas.length; i++) {
            if (reservas[i].fecha_inicio == null) {
                hayPendientes = true;
            } else {
                hayRealizadas = true;
            }

            cargarFilaReserva(reservas[i], tbodyPendientes, tbodyRealizadas, numeroCarga);
        }

        if (!hayPendientes) {
            var tr = document.createElement("tr");
            tr.innerHTML = "<td colspan='8'>No hay reservas pendientes</td>";
            tbodyPendientes.appendChild(tr);
        }

        if (!hayRealizadas) {
            var tr = document.createElement("tr");
            tr.innerHTML = "<td colspan='7'>No hay reservas realizadas</td>";
            tbodyRealizadas.appendChild(tr);
        }
    });
}
function cargarTablaRecursos(idModelo) {
    var tbodyOperativos = document.getElementById("recursos_operativos_body");
    tbodyOperativos.innerHTML = "";

    idModelo = Number(idModelo);
    // Obtener recursos del modelo seleccionado y cargarlos en la tabla
    obtenerRecursos(idModelo, function(recursos_modelo) {
        if (!recursos_modelo || recursos_modelo.length === 0) {
            var tr = document.createElement("tr");
            tr.innerHTML = "<td colspan='5'>No hay recursos operativos</td>";
            tbodyOperativos.appendChild(tr);
            return;
        }
        // Obtener ubicaciones para mostrar el nombre en la tabla
        obtenerUbicaciones(function(ubicaciones) {
            for (let i = 0; i < recursos_modelo.length; i++) {
                let recursoActual = recursos_modelo[i];
                // Obtener reseñas para calcular la valoración media del recurso
                obtenerResenyas(recursoActual.id, function(resenyas) {
                    var ubicacion = null;
                    var valoracion_media = 0;

                    if (resenyas && resenyas.length > 0) {
                        for (var r = 0; r < resenyas.length; r++) {
                            valoracion_media += Number(resenyas[r].valor);
                        }
                        valoracion_media = valoracion_media / resenyas.length;
                    }

                    for (var z = 0; z < ubicaciones.length; z++) {
                        if (Number(ubicaciones[z].id) === Number(recursoActual.ubicacion)) {
                            ubicacion = ubicaciones[z];
                            break;
                        }
                    }

                    var numeroSerie = recursoActual.numero_serie;
                    var nombreubicacion = ubicacion ? ubicacion.nombre : "";

                    tiempoPendiente(recursoActual.id, function(horasRestantes) {
                        var tr = document.createElement("tr");
                        var textoHoras = "";
                        var boton = "";
                        // Si el recurso está disponible (horas restantes 0) se muestra "Disponible" y un botón para retirar directamente, si no se muestra el tiempo restante y un botón para reservar
                        if (Number(horasRestantes) === 0) {
                            textoHoras = "Disponible";
                            boton = "<button onclick='hacerRetiradaDirecta(" + recursoActual.id + ")'>Retirar</button>";
                        } else {
                            textoHoras = Number(horasRestantes).toFixed(1); // Mostrar horas restantes con un decimal
                            boton = "<button onclick='hacerReserva(" + recursoActual.id + ")'>Reservar</button>";
                        }

                        tr.innerHTML =
                            "<td>" + numeroSerie + "</td>" +
                            "<td>" + nombreubicacion + "</td>" +
                            "<td>" + textoHoras + "</td>" +
                            "<td>" + valoracion_media.toFixed(1) + "</td>" +
                            "<td>" + boton + "</td>";

                        tbodyOperativos.appendChild(tr);
                    });
                });
            }
        });
    });
}

function cargarFilaReserva(reserva, tbodyPendientes, tbodyRealizadas, numeroCarga) {
    obtenerRecurso(reserva.recurso, function (recurso) {
        if (recurso == null) {
            return;
        }

        obtenerModelos(function (modelos) {
            obtenerCategorias(function (categorias) {
                obtenerUbicaciones(function (ubicaciones) {
                    var modelo = null;
                    var categoria = null;
                    var ubicacion=null;
                    for (var j = 0; j < modelos.length; j++) {
                        if (Number(modelos[j].id) === Number(recurso.modelo)) {
                            modelo = modelos[j];
                            break;
                        }
                    }

                    if (modelo != null) {
                        for (var k = 0; k < categorias.length; k++) {
                            if (Number(categorias[k].id) === Number(modelo.categoria)) {
                                categoria = categorias[k];
                                break;
                            }
                        }
                    }
                    for (var z = 0; z < ubicaciones.length; z++) {
                        if (Number(ubicaciones[z].id) === Number(recurso.ubicacion)) {
                            ubicacion = ubicaciones[z];
                            break;
                        }
                    }
                    var nombreCategoria = categoria ? categoria.nombre : ""; // Si no se encuentra la categoría, mostrar cadena vacía
                    var nombreModelo = modelo ? modelo.nombre : "";
                    var numeroSerie = recurso.numero_serie;
                    var nombreubicacion = ubicacion ? ubicacion.nombre : "";

                    if (reserva.fecha_inicio == null) {
                        tiempoPendienteReserva(reserva.id, function (horasParaRetirar) {
                            if (numeroCarga !== cargaReservasActual) {
                                return;
                            }
                            console.log("Horas restantes para la reserva " + reserva.id + ": " + horasParaRetirar);

                            if (horasParaRetirar == null) {
                                horasParaRetirar = 0;
                            }

                            var tr = document.createElement("tr");

                            var botonRetirar = "";
                            if (Number(horasParaRetirar) <= 0) {
                                botonRetirar = "<button onclick='retirarReserva(" + reserva.id + ")'>Retirar</button>";
                            }

                            tr.innerHTML =
                                "<td>" + nombreCategoria + "</td>" +
                                "<td>" + nombreModelo + "</td>" +
                                "<td>" + numeroSerie + "</td>" +
                                "<td>" + nombreubicacion + "</td>" +
                                "<td>" + formatearFecha(reserva.fecha_peticion) + "</td>" +
                                "<td>" + Number(horasParaRetirar).toFixed(1) + "</td>" +
                                "<td>" + botonRetirar + "</td>" +
                                "<td><button onclick='borrarReserva(" + reserva.id + ")'>X</button></td>";

                            tbodyPendientes.appendChild(tr);
                        });
                    } else {
                        if (numeroCarga !== cargaReservasActual) {
                            return;
                        }
                        var tr = document.createElement("tr");

                        var celdaFin = "";
                        if (reserva.fecha_fin == null) {
                            celdaFin = "<button onclick='devolverReserva(" + reserva.id + ")'>Devolver</button>";
                        } else {
                            celdaFin = formatearFecha(reserva.fecha_fin);
                        }

                        tr.innerHTML =
                            "<td>" + nombreCategoria + "</td>" +
                            "<td>" + nombreModelo + "</td>" +
                            "<td>" + numeroSerie + "</td>" +
                            "<td>" + reserva.horas_estimadas + "</td>" +
                            "<td>" + formatearFecha(reserva.fecha_inicio) + "</td>" +
                            "<td>" + celdaFin + "</td>" +
                            "<td><button onclick='abrirResenya(" + reserva.recurso + ")'>Reseña</button></td>";
                        
                        tbodyRealizadas.appendChild(tr);
                    }
                });
            });
        });
    });
}
var idSanitarioLogueado = null;

function entrar() {
    
    var usuario = document.getElementById("usuario_log").value;
    var password = document.getElementById("contraseña_log").value;

    if (!usuario || !password) {
        alert("Introduce usuario y contraseña");
        return;
    }
    // Realizar login del sanitario con los datos introducidos
    loginSanitario(usuario, password, function (id) {
        if (id == null) {
            alert("Usuario o contraseña incorrectos");
            return;
        }

        idSanitarioLogueado = id;
        // Obtener datos del sanitario logueado para mostrar su nombre en la bienvenida y cargar sus reservas
        obtenerSanitario(id, function (sanitario) {
            if (sanitario == null) {
                alert("Error al obtener el sanitario");
                return;
            }
            sanitarioLogueado=sanitario;
            abrirWSSanitario();
            document.getElementById("nombre_bienvenida").textContent =
                sanitario.nombre + " " + sanitario.apellidos;

            cargarTablasReservas(idSanitarioLogueado);
            cambiarSeccion("principal");
        });
    });
}
function registrar() {
    document.getElementById("nombre_reg").value = "";
    document.getElementById("apellidos").value = "";
    document.getElementById("usuario_reg").value = "";
    document.getElementById("contraseña_reg").value = "";
    guardar_resenya = false
    cambiarSeccion("registro");
}
function guardar(){
    // Crear objeto con los datos del formulario
    var user={nombre:document.getElementById("nombre_reg").value, 
            apellidos:document.getElementById("apellidos").value, 
            usuario:document.getElementById("usuario_reg").value, 
            password:document.getElementById("contraseña_reg").value}
    if(esNuevoRegistro){
        crearSanitario(user,function(id){
            if(id!=null){
                console.log("Sanitario creado");
                cambiarSeccion("inicio");
            }
            else{
                alert("Error al crear el sanitario")
            }
        });
    }
    else if(guardar_resenya){
        valoracion=document.getElementById("Valoracion").value;
        descripcion=document.getElementById("comentario").value;
        crearResenya(recursoResenya_id,idSanitarioLogueado,valoracion,descripcion,function(id){
            if(id!=null){
                console.log("Reseña creada");

                enviarWS({
                    operacion: "resenyaCreada",
                    idRecurso: recursoResenya_id,
                    valoracion: valoracion
                });

                cambiarSeccion("principal");
            }
            else{
                alert("Error al crear la reseña")
            }
        })

    }
    else{
        actualizarSanitario(idSanitarioLogueado,user,function(respuesta){
            if(respuesta){
                console.log("Sanitario actualizado");
                sanitarioLogueado.nombre = user.nombre;
                sanitarioLogueado.apellidos = user.apellidos;
                sanitarioLogueado.usuario = user.usuario;
                document.getElementById("nombre_bienvenida").textContent = user.nombre + " " + user.apellidos;
                cambiarSeccion("principal");
            }
            else{
                alert("Error al actualizar el sanitario")
            }
        });
    }
}
function cancelar(){
    guardar_resenya = false
    if(esNuevoRegistro){
        cambiarSeccion("inicio"); //vuelve al inicio para iniciar sesion con la nueva cuenta
    }
    else{
        cambiarSeccion("principal");
    }
}
function editar_datos(){
    esNuevoRegistro=false; // Viene de principal
    guardar_resenya = false
    // Llenar campos con datos del gestor logueado
    obtenerSanitario(idSanitarioLogueado,function(sanitario_log){
        document.getElementById("nombre_reg").value = sanitario_log.nombre;
        document.getElementById("apellidos").value = sanitario_log.apellidos;
        document.getElementById("usuario_reg").value = sanitario_log.usuario;
        document.getElementById("contraseña_reg").value = ""; // Contraseña vacía por seguridad
        cambiarSeccion("registro");
    });
    
}
function salir(){
    // Limpiar datos y volver a la pantalla de inicio de sesión
    cerrarWS();
    avisos = [];
    pintarAvisos();
    esNuevoRegistro=true;
    sanitarioLogueado=null;
    guardar_resenya= false;
    recursoResenya_id=null;
    cambiarSeccion("inicio");
}
function abrirResenya(id){
    obtenerRecurso(id,function(recurso_info){
        if(recurso_info!=null){
            document.getElementById("recurso_info").textContent = recurso_info.numero_serie;
            document.getElementById("Valoracion").value = "";
            document.getElementById("comentario").value = "";   
            cambiarSeccion("resenya");
            esNuevoRegistro=false;
            guardar_resenya= true;
            recursoResenya_id=id;
        }
    });
}
function nueva_reserva() {
    cambiarSeccion("reserva");
    guardar_resenya = false
    obtenerCategorias(function(categorias_todas) {
        llenarSelect("categoria_info", categorias_todas);
        document.getElementById("tiempo_uso").value = "";
        cargarModelosFormulario();
        esNuevoRegistro = false;
    });
}  
function cargarModelosFormulario() {
    var categoriaSeleccionada = document.getElementById("categoria_info").value;

    obtenerModelos(function(todosLosModelos) {
        var modelosFiltrados = todosLosModelos.filter(function(m) {
            return Number(m.categoria) === Number(categoriaSeleccionada);
        });

        llenarSelect("modelo_info", modelosFiltrados);
        actualizarTablaRecursos();
    });
}
function actualizarTablaRecursos() {
    var idModelo = document.getElementById("modelo_info").value;
    if (idModelo) {
        cargarTablaRecursos(idModelo);
    }
}

function hacerReserva(idRecurso) {
    var tiempo_est = Number(document.getElementById("tiempo_uso").value);

    if (!tiempo_est || tiempo_est <= 0) {
        alert("Introduce un tiempo estimado de uso válido");
        return;
    }

    reservarRecurso(idRecurso, idSanitarioLogueado, tiempo_est, function(idReserva) {
        if (idReserva == null) {
            alert("No se pudo crear la reserva");
            return;
        }

        alert("Reserva creada correctamente");
        cargarTablasReservas(idSanitarioLogueado);
        actualizarTablaRecursos();
        cambiarSeccion("principal");
    });
}
function hacerRetiradaDirecta(idRecurso) {
    var tiempo_est = Number(document.getElementById("tiempo_uso").value);

    if (!tiempo_est || tiempo_est <= 0) {
        alert("Introduce un tiempo estimado de uso válido");
        return;
    }

    reservarRecurso(idRecurso, idSanitarioLogueado, tiempo_est, function(idReserva) {
        if (idReserva == null) {
            alert("No se pudo retirar el recurso");
            return;
        }

        iniciarReserva(idReserva, function(respuesta) {
            enviarWS({
                operacion: "reservaIniciada",
                idReserva: idReserva
            });
            cargarTablasReservas(idSanitarioLogueado);
            actualizarTablaRecursos();
            cambiarSeccion("principal");
        });
    });
}